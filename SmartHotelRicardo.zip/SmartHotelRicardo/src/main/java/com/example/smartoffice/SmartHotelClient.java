package com.example.smartoffice;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SmartHotelClient {
    public static void main(String[] args) {
        // Create a channel to the server
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()
                .build();

        // Create a stub for the SmartHotel service
        SmartHotelGrpc.SmartHotelBlockingStub stub = SmartHotelGrpc.newBlockingStub(channel);

        // Create GUI components
        JTextField guestNameField = new JTextField(20);
        JTextField roomNumberField = new JTextField(10);
        JButton checkInButton = new JButton("Check In");

        // Create GUI panel
        JPanel panel = new JPanel();
        panel.add(new JLabel("Guest Name:"));
        panel.add(guestNameField);
        panel.add(new JLabel("Room Number:"));
        panel.add(roomNumberField);
        panel.add(checkInButton);

        // Create GUI frame
        JFrame frame = new JFrame("Smart Hotel Check-In");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);

        // Add action listener for the checkInButton
        checkInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get guest name and room number from text fields
                String guestName = guestNameField.getText().trim();
                String roomNumber = roomNumberField.getText().trim();

                // Prepare check-in request
                CheckInRequest request = CheckInRequest.newBuilder()
                        .setGuestName(guestName)
                        .setRoomNumber(roomNumber)
                        .build();

                // Send check-in request to the server
                CheckInResponse response = stub.checkInGuest(request);

                // Process server response
                if (response.getSuccess()) {
                    JOptionPane.showMessageDialog(frame, "Check-in successful: " + response.getMessage());
                } else {
                    JOptionPane.showMessageDialog(frame, "Check-in failed: " + response.getMessage());
                }

                // Shutdown the channel
                channel.shutdown();
            }
        });
    }
}
