package com.example.smartoffice;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class SmartHotelServer {

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(9090)
                .addService(new SmartHotelServiceImpl()) // Register SmartHotel service implementation
                .build();

        server.start();

        System.out.println("Smart Hotel Server started on port 9090");

        server.awaitTermination();
    }
}

