package com.example.smartoffice;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class CheckOutServer {

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(9091) // Assuming a different port for the check-out server
                .addService(new CheckOutServiceImpl()) // Register CheckOut service implementation
                .build();

        server.start();

        System.out.println("Check-Out Server started on port 9091");

        server.awaitTermination();
    }
}
