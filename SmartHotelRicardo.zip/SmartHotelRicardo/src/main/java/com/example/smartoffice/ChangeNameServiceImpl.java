package com.example.smartoffice;

import io.grpc.stub.StreamObserver;

public class ChangeNameServiceImpl extends ChangeNameGrpc.ChangeNameImplBase {

    @Override
    public void changeGuestName(ChangeNameRequest request, StreamObserver<ChangeNameResponse> responseObserver) {
        // Perform guest name change logic
        String currentGuestName = request.getCurrentGuestName();
        String newGuestName = request.getNewGuestName();
        String roomNumber = request.getRoomNumber();

        // Dummy logic (can be replaced with actual guest name change procedure)
        boolean nameChangeSuccessful = performNameChange(currentGuestName, newGuestName, roomNumber);

        // Prepare response based on name change result
        String message;
        if (nameChangeSuccessful) {
            message = "Guest name changed successfully from " + currentGuestName + " to " + newGuestName + " for room " + roomNumber;
        } else {
            message = "Failed to change guest name for room " + roomNumber;
        }

        // Build and send the response
        ChangeNameResponse response = ChangeNameResponse.newBuilder()
                .setSuccess(nameChangeSuccessful)
                .setMessage(message)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Dummy logic (replace with actual guest name change procedure)
    private boolean performNameChange(String currentGuestName, String newGuestName, String roomNumber) {
        // Simulate successful name change for demonstration purposes
        return true;
    }
}
