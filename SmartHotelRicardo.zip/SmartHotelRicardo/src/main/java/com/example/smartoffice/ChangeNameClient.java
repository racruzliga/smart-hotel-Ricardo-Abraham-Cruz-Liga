package com.example.smartoffice;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangeNameClient {
    public static void main(String[] args) {
        // Create a channel to the name change server
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9092)
                .usePlaintext()
                .build();

        // Create a stub for the ChangeName service
        ChangeNameGrpc.ChangeNameBlockingStub stub = ChangeNameGrpc.newBlockingStub(channel);

        // Create GUI components
        JTextField currentNameField = new JTextField(20);
        JTextField newNameField = new JTextField(20);
        JTextField roomNumberField = new JTextField(10);
        JButton changeNameButton = new JButton("Change Name");

        // Create GUI panel
        JPanel panel = new JPanel();
        panel.add(new JLabel("Current Guest Name:"));
        panel.add(currentNameField);
        panel.add(new JLabel("New Guest Name:"));
        panel.add(newNameField);
        panel.add(new JLabel("Room Number:"));
        panel.add(roomNumberField);
        panel.add(changeNameButton);

        // Create GUI frame
        JFrame frame = new JFrame("Change Name Client");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);

        // Add action listener for the changeNameButton
        changeNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get current guest name, new guest name, and room number from text fields
                String currentName = currentNameField.getText().trim();
                String newName = newNameField.getText().trim();
                String roomNumber = roomNumberField.getText().trim();

                // Prepare change name request
                ChangeNameRequest request = ChangeNameRequest.newBuilder()
                        .setCurrentGuestName(currentName)
                        .setNewGuestName(newName)
                        .setRoomNumber(roomNumber)
                        .build();

                // Send change name request to the server
                ChangeNameResponse response = stub.changeGuestName(request);

                // Process server response
                if (response.getSuccess()) {
                    JOptionPane.showMessageDialog(frame, "Name change successful: " + response.getMessage());
                } else {
                    JOptionPane.showMessageDialog(frame, "Name change failed: " + response.getMessage());
                }

                // Shutdown the channel
                channel.shutdown();
            }
        });
    }
}
