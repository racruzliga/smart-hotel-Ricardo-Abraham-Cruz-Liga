package com.example.smartoffice;

import io.grpc.stub.StreamObserver;

public class SmartHotelServiceImpl extends SmartHotelGrpc.SmartHotelImplBase {

    @Override
    public void checkInGuest(CheckInRequest request, StreamObserver<CheckInResponse> responseObserver) {
        // Perform check-in logic
        String guestName = request.getGuestName();
        String roomNumber = request.getRoomNumber();

        // Dummy check-in logic (can be replaced with actual hotel check-in procedure)
        boolean checkInSuccessful = performCheckIn(guestName, roomNumber);

        // Prepare response based on check-in result
        String message;
        if (checkInSuccessful) {
            message = "Check-in successful for " + guestName + " in room " + roomNumber;
        } else {
            message = "Check-in failed for " + guestName + " in room " + roomNumber;
        }

        // Build and send the response
        CheckInResponse response = CheckInResponse.newBuilder()
                .setSuccess(checkInSuccessful)
                .setMessage(message)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Dummy check-in logic (replace with actual hotel check-in procedure)
    private boolean performCheckIn(String guestName, String roomNumber) {
        // Simulate successful check-in for demonstration purposes
        return true;
    }
}
