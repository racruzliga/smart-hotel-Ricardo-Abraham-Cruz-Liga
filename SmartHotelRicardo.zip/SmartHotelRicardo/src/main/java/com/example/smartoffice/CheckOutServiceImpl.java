package com.example.smartoffice;

import io.grpc.stub.StreamObserver;

public class CheckOutServiceImpl extends CheckOutGrpc.CheckOutImplBase {

    @Override
    public void checkOutGuest(CheckOutRequest request, StreamObserver<CheckOutResponse> responseObserver) {
        // Perform check-out logic
        String guestName = request.getGuestName();
        String roomNumber = request.getRoomNumber();

        // Dummy check-out logic (can be replaced with actual hotel check-out procedure)
        boolean checkOutSuccessful = performCheckOut(guestName, roomNumber);

        // Prepare response based on check-out result
        String message;
        if (checkOutSuccessful) {
            message = "Check-out successful for " + guestName + " from room " + roomNumber;
        } else {
            message = "Check-out failed for " + guestName + " from room " + roomNumber;
        }

        // Build and send the response
        CheckOutResponse response = CheckOutResponse.newBuilder()
                .setSuccess(checkOutSuccessful)
                .setMessage(message)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Dummy check-out logic (replace with actual hotel check-out procedure)
    private boolean performCheckOut(String guestName, String roomNumber) {
        // Simulate successful check-out for demonstration purposes
        return true;
    }
}
