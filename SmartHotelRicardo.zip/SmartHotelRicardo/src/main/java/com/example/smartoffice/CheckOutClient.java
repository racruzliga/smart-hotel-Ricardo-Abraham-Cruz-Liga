package com.example.smartoffice;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckOutClient {
    public static void main(String[] args) {
        // Create a channel to the check-out server
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9091)
                .usePlaintext()
                .build();

        // Create a stub for the CheckOut service
        CheckOutGrpc.CheckOutBlockingStub stub = CheckOutGrpc.newBlockingStub(channel);

        // Create GUI components
        JTextField guestNameField = new JTextField(20);
        JTextField roomNumberField = new JTextField(10);
        JButton checkOutButton = new JButton("Check Out");

        // Create GUI panel
        JPanel panel = new JPanel();
        panel.add(new JLabel("Guest Name:"));
        panel.add(guestNameField);
        panel.add(new JLabel("Room Number:"));
        panel.add(roomNumberField);
        panel.add(checkOutButton);

        // Create GUI frame
        JFrame frame = new JFrame("Smart Hotel Check-Out");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);

        // Add action listener for the checkOutButton
        checkOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get guest name and room number from text fields
                String guestName = guestNameField.getText().trim();
                String roomNumber = roomNumberField.getText().trim();

                // Prepare check-out request
                CheckOutRequest request = CheckOutRequest.newBuilder()
                        .setGuestName(guestName)
                        .setRoomNumber(roomNumber)
                        .build();

                // Send check-out request to the server
                CheckOutResponse response = stub.checkOutGuest(request);

                // Process server response
                if (response.getSuccess()) {
                    JOptionPane.showMessageDialog(frame, "Check-out successful: " + response.getMessage());
                } else {
                    JOptionPane.showMessageDialog(frame, "Check-out failed: " + response.getMessage());
                }

                // Shutdown the channel
                channel.shutdown();
            }
        });
    }
}
