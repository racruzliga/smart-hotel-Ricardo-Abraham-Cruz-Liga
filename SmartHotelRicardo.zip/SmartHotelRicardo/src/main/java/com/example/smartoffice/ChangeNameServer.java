package com.example.smartoffice;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class ChangeNameServer {

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(9092) // Assuming a different port for the name change server
                .addService(new ChangeNameServiceImpl()) // Register ChangeName service implementation
                .build();

        server.start();

        System.out.println("Change Name Server started on port 9092");

        server.awaitTermination();
    }
}
